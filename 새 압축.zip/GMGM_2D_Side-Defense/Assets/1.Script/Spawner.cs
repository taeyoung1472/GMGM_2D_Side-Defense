using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    [SerializeField] private TimeManager timeManager;
    [SerializeField] private 
    void Start()
    {
        
    }
    void Update()
    {
        
    }

}
